using UnityEngine;

public interface IProjectile
{
    void setProjectile(Vector2 direction, float speed, GameObject owner);
}
