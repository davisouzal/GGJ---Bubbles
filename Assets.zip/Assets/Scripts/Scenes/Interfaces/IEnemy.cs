using UnityEngine;

public interface IEnemy
{
}
