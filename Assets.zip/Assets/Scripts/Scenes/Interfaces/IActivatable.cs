using UnityEngine;

public interface IActivatable { 
    
}
