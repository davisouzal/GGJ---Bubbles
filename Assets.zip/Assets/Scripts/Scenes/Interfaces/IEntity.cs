using UnityEngine;

public interface IEntity
{

}
