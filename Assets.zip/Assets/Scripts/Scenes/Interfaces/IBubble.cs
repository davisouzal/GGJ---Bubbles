using UnityEngine;
public interface IBubble
{
}
