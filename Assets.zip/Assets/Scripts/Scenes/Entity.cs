using UnityEngine;

public class Entity : MonoBehaviour, IEntity
{
   
}
