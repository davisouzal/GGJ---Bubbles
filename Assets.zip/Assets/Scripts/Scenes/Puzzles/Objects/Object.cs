using UnityEngine;

public class Object : MonoBehaviour, IActivatable
{}
