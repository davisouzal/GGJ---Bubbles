using UnityEngine;

public class starterProject : MonoBehaviour
{ 
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    // void Start()
    // {
    //     this.setProjectile(transform.position, 5f, gameObject);
    // }
}
